This is the Test Driver for Spelling Corrector. This driver is provided for those with the knowledge and know-how to enable them to run tests through the terminal and other such activities. If you use this file YOU are responsible for getting it to work, you will not receive help from the TAs. 

If you do no understand this file, then please do no use it and stick to the IntelliJ tests and tutorial that have been provided for you.
